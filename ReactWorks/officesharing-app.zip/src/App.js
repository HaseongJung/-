//import logo from './logo.svg';
import './App.css';
import Heading from './components/Heading';
import ReservList from './components/ReservList';

function App() {
  return (
    <>
    <Heading/>
    <hr/>
    <ReservList/>
    </>
  );
}

export default App;
