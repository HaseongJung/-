import { useState } from "react";

const ReservForm = ({rooms, setRooms, reservs, setReservs}) => {
    // State variables
    const [warning, setWarning] = useState('');
    const [reserv, setReserv] = useState({
        customer: '',
        id: '',
        persons: 0,
        time:0,
        price: 0,
        reserved: false
    });

    // 입력값 변경 이벤트 처리기
    const handleInputReserv = (e) => {
        setReserv((reserv) => ({
            ...reserv,
            [e.target.name]: e.target.value
        }));
    };

    const handleSubmit = (e) => { 
        e.preventDefault(); // 폼 제출에 의한 페이지 리로딩 방지
        const tempRoom = rooms.find((r) => r.id === Number(reserv.id));
        if (tempRoom) {
            // 예약자명이 빈 문자열인지 확인
            if (reserv.customer.trim() === '') {
                setWarning("예약자명을 입력하세요!");
                return;
            }
            if (tempRoom.capacity < reserv.persons) {
                setWarning("인원수가 초과되었습니다!");
                return;
            }
            // 예약된 미팅룸인지 확인
            if (tempRoom.reserved) {
                setWarning("이미 예약된 미팅룸입니다!");
                return;
            }
            // 이용시간이 0인지 확인
            if (tempRoom.time <= 0) {
                setWarning("이용시간을 확인하세요!");
                return;
            }
            reserv.price = (tempRoom.price * reserv.time/3)*reserv.time;
            reserv.reserved = true;
            // 새로 생성된 예약 객체를 부모 컴포넌트(ReservItem)로 전달
            setReservs(reservs.concat(reserv));
            setRooms([
                ...rooms.filter((m) => (m.id !== Number(reserv.id))),
            ]);
            setReservs(reservs.concat(reserv));
            setReserv({
                customer: '',
                id: '',
                persons: 0,
                time: 0,
                price: 0
            });
            setWarning('');
        }
        else {setWarning("방 번호를 확인해주세요!")};
        };

    return (
        <>
        <h2>미팅룸 예약</h2>
        <form onSubmit={handleSubmit}>
            <label>
                예약자: <input type="text" onChange={handleInputReserv} name="customer" value={reserv.customer}/><br/>
            </label>
            <label>
                룸 번호: <input type="text" onChange={handleInputReserv} name="id" value={reserv.id}/><br/>
            </label>
            <label>
                인원: <input type="text" onChange={handleInputReserv} name="persons" value={reserv.persons}/><br/>
            </label>
            <label>
                이용시간: <input type="text" onChange={handleInputReserv} name="time" value={reserv.time}/>
            </label>
            <br/>
            <button>Reservation</button><br/>
        <span style={{color: 'red'}}>{warning}</span>
        </form>
        </>
    );
};

export default ReservForm;