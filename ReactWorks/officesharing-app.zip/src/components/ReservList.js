import { useState } from "react";
import ReservItem from "./ReservItem";
import ReservItem2 from "./ReservItem2";
import ReservForm from "./ReservForm";

const ReservList = () => {
    // 예약 가능한 미팅룸
    const [rooms, setRooms] = useState([
        {id: 101, name: "Lemon", capacity: 10, price: 100000, reserved: false},
        {id: 102, name: "Cherry", capacity: 8, price: 80000, reserved: false},
        {id: 202, name: "Ocean", capacity: 6, price: 60000, reserved: false},
        {id: 203, name: "Sky", capacity: 4, price: 40000, reserved: false},
        {id: 205, name: "Forest", capacity: 2, price: 20000, reserved: false},
        {id: 301, name: "Smile", capacity: 2, price: 20000, reserved: false},
        {id: 303, name: "Cloud", capacity: 2, price: 20000, reserved: false}
    ]);
    
    // 현재 예약된 미팅룸
    const [reservs, setReservs] = useState([
        {id: 103, customer: "Tom", persons: 6, time: 3, price: 70000},
        {id: 201, customer: "Alice", persons: 3, time: 5, price: 120000}
    ]);
    

    // 예약 가능한 미팅룸 리스트
    const rows = rooms.map((room) => <ReservItem key={room.id} room={room} setRooms={setRooms}/>);
    const rows2 = reservs.map((room) => <ReservItem2 key={room.id} reserv={room} setRooms={setRooms}/>);

    return (
        <>
        <h2>Meeting Rooms Reservation</h2>
        <h2>예약 가능한 미팅룸 리스트</h2>
        <table style={{border: "1px solid black"}}>
            <thead>
                <tr>
                    <th>Room No</th><th>Room Name</th><th>Persons</th><th>Price(3hours)</th>
                </tr>
            </thead>
            <tbody>
                {rows}
            </tbody>
        </table>
        <ReservForm rooms={rooms} setRooms={setRooms} reservs={reservs} setReservs={setReservs}/>
        <br/>
        <h2>미팅룸 예약현황</h2>
        <table style={{border:"1px solid black"}}>
            <thead>
                <tr>
                    <th>Room NO</th><th>Customer</th><th>Persons</th><th>Hours</th><th>Price</th>
                </tr>
            </thead>
            <tbody>
                {rows2}
            </tbody>
        </table>
        <br/>
        </>
    );
}
export default ReservList;