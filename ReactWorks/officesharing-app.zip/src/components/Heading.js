const Heading = () => {
    return (
        <>
        <h1>[ WeWork ] Office Sharing Service</h1>
        </>
    );
}
export default Heading;