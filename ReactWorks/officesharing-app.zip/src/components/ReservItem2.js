const ReservItem2 = (props) => {
    const {customer, id, persons, time, price} = props.reserv;

    return (
        <>
        <tr>
            <td>{id}</td>
            <td>{customer}</td>
            <td>{persons}</td>
            <td>{time}</td>
            <td>{price}</td>
        </tr>
        </>
    );
}
export default ReservItem2;