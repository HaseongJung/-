const ReservItem = (props) => {
    const {id, name, capacity, price} = props.room;
    

    return (
        <>
        <tr>
            <td>{id}</td>
            <td>{name}</td>
            <td>{capacity}</td>
            <td>{price}</td>
        </tr>
        </>
    );
}
export default ReservItem;